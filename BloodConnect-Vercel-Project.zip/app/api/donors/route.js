export async function GET(){return Response.json({donors:[{name:"Arun Kumar",bloodGroup:"O+",city:"Coimbatore",availability:true}]})}
