export async function POST(req){const body=await req.json(); return Response.json({success:true,requestId:"BC-DEMO-001",received:body});}
