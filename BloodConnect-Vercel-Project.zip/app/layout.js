import "./globals.css";
import Link from "next/link";
export const metadata={title:"BloodConnect – Online Blood Donor Finder",description:"Find blood. Save lives."};
export default function Layout({children}){
 return <html lang="en"><body><header className="nav"><Link className="brand" href="/">🩸 BloodConnect</Link><nav><Link href="/">Home</Link><Link href="/find-donor">Find Donor</Link><Link href="/register">Register</Link><Link href="/emergency-request">Emergency</Link><Link href="/about">About</Link><Link href="/login">Login</Link></nav></header>{children}<footer>© 2026 BloodConnect · Find Blood. Save Lives.</footer></body></html>
}