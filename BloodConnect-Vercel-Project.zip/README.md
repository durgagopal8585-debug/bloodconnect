# BloodConnect
Vercel-ready Next.js college project demo.

## Run
npm install
npm run dev

## Pages
Home, Find Donor, Register, Login, Donor Dashboard, Emergency Request, About, Admin Dashboard.

## Database
`database/schema.sql` contains the MySQL schema and sample records.

## Production backend
Connect the API routes/server actions to your MySQL provider using environment variables such as `DATABASE_URL`. Never store plaintext passwords; use bcrypt/argon2 and prepared queries.

## Vercel
Import this repository/project into Vercel and deploy. For a production database, use a managed MySQL-compatible provider and configure its environment variables in Vercel.
